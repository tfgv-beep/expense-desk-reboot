
# CRM عقاري — خطة التنفيذ

## نقطة البداية
المشروع الحالي (ExpenseDesk) **هيتمسح بالكامل**. هنبني CRM جديد على Lovable Cloud باستخدام الـ schema والـ permissions matrix الموجودين في الـ zip كـ source of truth.

## الـ Stack النهائي
- **Frontend**: React + Vite + Tailwind + shadcn/ui + framer-motion
- **Backend**: Lovable Cloud (Supabase) — Postgres + Auth + Storage + Edge Functions + Realtime
- **Mobile (iOS/Android)**: Capacitor — نفس الكود يتحول لـ native apps
- **i18n**: react-i18next مع دعم RTL/LTR كامل
- **Theme**: Dark افتراضي، Modern Dark (indigo/violet)، زرار toggle للـ light
- **اللغة الافتراضية**: عربي (RTL)

## الأدوار (Roles)
`ceo` (= admin أعلى), `admin`, `director`, `team_leader`, `sales` — منقولة من الـ zip بنفس الصلاحيات الافتراضية.

## المراحل (Phases)

### Phase 1 — الأساس والصلاحيات (نبدأ بيه دلوقتي)
- مسح ExpenseDesk القديم.
- Design system جديد: Modern Dark (#0F172A / #6366F1 / #A78BFA) + framer-motion.
- نظام i18n (AR/EN) + RTL + Theme toggle (dark/light).
- Auth كامل:
  - Sign up (اسم، ايميل، باسورد، تأكيد باسورد، اختيار role من dropdown).
  - لو اختار sales → يظهر حقل "Team Leader بتاعك".
  - تحقق unique للايميل والاسم.
  - Email verification.
  - Google + Facebook OAuth (ملاحظة: Facebook مش مدعوم native في Lovable Cloud — هنوصل Supabase خارجي أو نكتفي بـ Google + Email).
  - Forgot password + Reset password page.
- **Approval flow**: مستخدم جديد = `pending` → صفحة Admin "Pending Approvals" بكروت كاملة → موافقة/رفض/تعديل → إشعار ايميل للمستخدم.
- **CEO default user**: seed تلقائي.
- Database schema (من الـ zip): `profiles`, `user_roles`, `role_permissions`, `user_permission_overrides`, `pending_approvals`.
- **Permissions Matrix page** (Admin): جدول role × permission بـ on/off switches، تأثير فوري على كل المستخدمين الحاليين والجدد.
- **Per-user overrides page** (Admin): فتح/قفل فنكشن معين لموظف واحد بس.
- Audit log (كل action معروف مين عمله).

### Phase 2 — Leads + Kanban + Activities
- Dashboard السيلز بكروت متحركة (Leads / Resale / Planner / My Profile Card) بـ hover popups.
- صفحة Leads فيها: current/new/contacted/meeting/done کارتات إحصائية.
- **Kanban Board**: New → Called → Qualified → Proposal → Negotiation → Won/Lost (drag & drop).
- Lead Activities (calls/messages/meetings) + outcome + next action + feedback.
- Lead assignment: sales واحد، share بين 2 سيلز، broadcast لكذا سيلز.
- Lead delay (تأجيل لفترة معينة).
- Lead reassignment (admin/director يسحب lead من sales لـ sales تاني).
- Field masking (إخفاء phone/email/notes حسب الصلاحية).
- Lead locks + blocks.
- Bulk import من CSV/Excel.

### Phase 3 — Resale Market + Projects
- صفحة Resale زي Amazon: كروت بألبوم صور (≤5)، السعر، الدور، المساحة.
- بيانات المالك (اسم/تليفون) — إخفاء حسب assignment وصلاحية الـ admin.
- Projects Library: إضافة/تعديل/حذف مشاريع (صور، اسم، مالك، مكان، مميزات، متوسط أسعار، أنواع وحدات).
- Auto-fill: لما sales يختار مشروع وهو بيضيف lead → بياناته تتعبى تلقائياً.

### Phase 4 — Planner + Profile Card
- Planner: نوت تفاعلي لكل sales — مهام يومه، structure، tick على المنفذ.
- Profile Card: صورة، اسم، تايتل، social links (FB/IG/phone) — كارد شيك بـ animation.

### Phase 5 — Reports + Live Dashboard
- Live dashboard للـ CEO: عملاء جدد اليوم، مكالمات، top performer، response rate، who's online now.
- Activity tracking realtime (مين بيعمل إيه دلوقتي).
- صفحة Reports القوية: فلاتر متعددة (يوم/أسبوع/شهر/فترة custom)، per-employee performance، calls/leads/sales/revenue، export CSV/Excel.
- Sales targets شهرية + متابعتها.

### Phase 6 — Mobile (iOS + Android)
- Capacitor setup.
- تجهيز التطبيق للنشر على App Store + Play Store.
- المستخدم يصدر المشروع لـ GitHub ويبني الـ apps من جهازه (محتاج Mac/Xcode لـ iOS).

## التفاصيل التقنية

### Database Tables (Phase 1)
```text
profiles            (id, full_name, avatar_url, title, bio, phone, social_links, status)
user_roles          (user_id, role)  -- منفصل عن profiles لمنع privilege escalation
role_permissions    (role, permission_key, enabled)
user_overrides      (user_id, permission_key, enabled)  -- override per-user
pending_approvals   (id, user_id, role_requested, team_leader_id, status)
audit_logs          (id, user_id, action, entity_type, entity_id, metadata, timestamp)
```

### Security
- RLS على كل جدول.
- Security definer function `has_permission(user_id, permission_key)` تجمع الـ role default + user override.
- منع تعديل role من client.
- Service role في Edge Functions للـ approvals والإشعارات.

### Notifications
- Email عبر Lovable Emails (transactional) لـ verification, approval, reset password.

### حدود الـ OAuth
- **Google**: مدعوم native في Lovable Cloud ✅
- **Facebook**: مش مدعوم native — لو ضروري لازم نوصل Supabase خارجي. هنبدأ بـ Google + Email وممكن نضيف Facebook بعدين لو احتجنا.

## ASCII Map (Phase 1)
```text
/login        -> Login form + Google OAuth + forgot password link
/signup       -> Name, Email, Password, Confirm, Role dropdown, Team Leader (if sales)
/verify-email -> Awaiting verification screen
/pending      -> "في انتظار موافقة الادمن" + ايميل لما توافق
/reset-password -> Set new password page
/app
  /dashboard          -> per-role landing
  /admin/approvals    -> Pending users cards (approve/reject/edit)
  /admin/employees    -> All employees list + per-user detail page
  /admin/permissions  -> Role × Permission matrix (on/off)
  /admin/overrides    -> Per-user permission overrides
  /profile            -> My profile card editor
  /settings           -> Language toggle (AR/EN) + Theme (Dark/Light)
```

## التنفيذ
أبدأ بـ **Phase 1 كامل** في الرد الجاي (مسح القديم، Auth، Roles، Approvals، Permissions matrix). الـ phases الباقية كل واحدة في رد منفصل (المشروع كبير جداً لرد واحد).
