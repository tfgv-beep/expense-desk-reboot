# Project Memory

## Core
EstateCRM — Real-estate CRM. React + Vite + Lovable Cloud. Replaces old ExpenseDesk.
Roles: ceo, admin, director, team_leader, sales. First user = CEO. Others = pending until approved.
Default language Arabic (RTL). Dark theme default (Modern Dark indigo/violet). Toggle via LangThemeToggle.
Permissions: role_permissions matrix + user_permission_overrides. AuthContext computes effective permissions.
Never edit src/integrations/supabase/client.ts. The lovable/index.ts cast was needed for SDK type bug.

## Memories
- [CRM Architecture](mem://features/crm-architecture) — Stack, roles, auth flow, permissions, DB tables, phase status
