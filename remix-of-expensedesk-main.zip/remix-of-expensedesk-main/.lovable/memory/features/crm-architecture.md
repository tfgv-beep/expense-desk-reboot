---
name: CRM Architecture
description: Real-estate CRM rebuilt on Lovable Cloud. Replaces ExpenseDesk. Roles, permissions matrix, approval flow.
type: feature
---
# EstateCRM — Real-Estate CRM

## Stack
- React + Vite + Tailwind + shadcn/ui + framer-motion
- Lovable Cloud (Supabase) for auth/db/storage
- react-i18next (AR default, RTL) + EN toggle
- ThemeContext: dark default (Modern Dark indigo/violet #6366F1/#A78BFA), light toggle
- Capacitor planned for iOS/Android (Phase 6)

## Roles
`ceo` | `admin` | `director` | `team_leader` | `sales`
- First registered user → auto CEO + active (bootstrap)
- All other signups → `pending` until admin approval
- CEO role is uneditable in PermissionsMatrix (always full access)

## Auth flow
- Email/password + Google OAuth (via lovable.auth.signInWithOAuth)
- Signup form: full_name, email, password, confirm, role dropdown; team_leader_id select shown ONLY when role=sales
- Metadata stored in raw_user_meta_data: full_name, requested_role, team_leader_id
- handle_new_user trigger reads metadata, creates profile + (role=ceo for first OR pending_approvals row)
- Routes: /login /signup /forgot-password /reset-password /verify-email /pending
- Protected route checks profile.status === 'active' else redirects to /pending

## Permissions
- `role_permissions(role, permission_key, enabled)` seeded with sensible defaults
- `user_permission_overrides(user_id, permission_key, enabled)` per-user override (delete row = inherit role)
- AuthContext loads roles + role_permissions + overrides → builds Set<string> permissions
- `has_permission(uid, key)` SQL function: override wins, else union of enabled role perms
- Permission keys list in `src/lib/permissions.ts` (PERMISSION_KEYS / PERMISSION_GROUPS)
- AppShell hides sidebar items via perm check; Protected route gates via requirePermission/adminOnly

## DB tables (Phase 1)
profiles, user_roles, role_permissions, user_permission_overrides, pending_approvals, audit_logs

## Phase status
- Phase 1 DONE: Auth, roles, approvals, permissions matrix, per-user overrides, profile, employees list
- Phase 2 TODO: Leads + Kanban + Activities + Assignment + bulk import
- Phase 3 TODO: Resale Market + Projects Library
- Phase 4 TODO: Planner + Profile Card animations
- Phase 5 TODO: Reports + Live Dashboard + Audit viewer
- Phase 6 TODO: Capacitor iOS/Android build
