
-- ============== CLEANUP OLD EXPENSEDESK SCHEMA ==============
DROP TABLE IF EXISTS public.approval_actions CASCADE;
DROP TABLE IF EXISTS public.expense_receipts CASCADE;
DROP TABLE IF EXISTS public.expenses CASCADE;
DROP TABLE IF EXISTS public.expense_categories CASCADE;
DROP TABLE IF EXISTS public.audit_logs CASCADE;
DROP TABLE IF EXISTS public.user_roles CASCADE;
DROP TABLE IF EXISTS public.profiles CASCADE;
DROP TYPE IF EXISTS public.app_role CASCADE;
DROP TYPE IF EXISTS public.expense_status CASCADE;
DROP FUNCTION IF EXISTS public.handle_new_user() CASCADE;
DROP FUNCTION IF EXISTS public.has_role(uuid, text) CASCADE;
DROP FUNCTION IF EXISTS public.is_manager_of(uuid, uuid) CASCADE;
DROP FUNCTION IF EXISTS public.update_updated_at() CASCADE;

-- ============== ROLE ENUM ==============
CREATE TYPE public.app_role AS ENUM ('ceo','admin','director','team_leader','sales');
CREATE TYPE public.user_status AS ENUM ('pending','active','rejected','suspended');

-- ============== PROFILES ==============
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  avatar_url TEXT,
  title TEXT,
  bio TEXT,
  phone TEXT,
  social_links JSONB DEFAULT '{}'::jsonb,
  status public.user_status NOT NULL DEFAULT 'pending',
  manager_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  last_seen_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- ============== USER ROLES ==============
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- ============== ROLE PERMISSIONS ==============
CREATE TABLE public.role_permissions (
  role public.app_role NOT NULL,
  permission_key TEXT NOT NULL,
  enabled BOOLEAN NOT NULL DEFAULT false,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (role, permission_key)
);
GRANT SELECT ON public.role_permissions TO authenticated;
GRANT ALL ON public.role_permissions TO service_role;
ALTER TABLE public.role_permissions ENABLE ROW LEVEL SECURITY;

-- ============== PER-USER PERMISSION OVERRIDES ==============
CREATE TABLE public.user_permission_overrides (
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  permission_key TEXT NOT NULL,
  enabled BOOLEAN NOT NULL,
  set_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, permission_key)
);
GRANT SELECT ON public.user_permission_overrides TO authenticated;
GRANT ALL ON public.user_permission_overrides TO service_role;
ALTER TABLE public.user_permission_overrides ENABLE ROW LEVEL SECURITY;

-- ============== PENDING APPROVALS ==============
CREATE TABLE public.pending_approvals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  requested_role public.app_role NOT NULL,
  team_leader_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'pending', -- pending|approved|rejected
  reviewed_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.pending_approvals TO authenticated;
GRANT ALL ON public.pending_approvals TO service_role;
ALTER TABLE public.pending_approvals ENABLE ROW LEVEL SECURITY;

-- ============== AUDIT LOGS ==============
CREATE TABLE public.audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  entity_type TEXT,
  entity_id TEXT,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.audit_logs TO authenticated;
GRANT ALL ON public.audit_logs TO service_role;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- ============== HELPER FUNCTIONS ==============
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

CREATE OR REPLACE FUNCTION public.is_admin(_user_id UUID)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role IN ('ceo','admin'))
$$;

CREATE OR REPLACE FUNCTION public.has_permission(_user_id UUID, _key TEXT)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT COALESCE(
    (SELECT enabled FROM public.user_permission_overrides WHERE user_id = _user_id AND permission_key = _key),
    (SELECT bool_or(rp.enabled) FROM public.role_permissions rp
       JOIN public.user_roles ur ON ur.role = rp.role
       WHERE ur.user_id = _user_id AND rp.permission_key = _key),
    false
  )
$$;

CREATE OR REPLACE FUNCTION public.is_user_active(_user_id UUID)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.profiles WHERE id = _user_id AND status = 'active')
$$;

CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

-- ============== NEW USER TRIGGER ==============
-- First registered user becomes CEO + active. Others go to pending.
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_user_count INT;
  v_requested_role public.app_role;
  v_team_leader UUID;
  v_full_name TEXT;
BEGIN
  SELECT count(*) INTO v_user_count FROM public.profiles;
  v_full_name := COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1));
  v_requested_role := COALESCE((NEW.raw_user_meta_data->>'requested_role')::public.app_role, 'sales');
  v_team_leader := NULLIF(NEW.raw_user_meta_data->>'team_leader_id','')::uuid;

  INSERT INTO public.profiles (id, full_name, email, status, manager_id)
  VALUES (
    NEW.id,
    v_full_name,
    NEW.email,
    CASE WHEN v_user_count = 0 THEN 'active'::public.user_status ELSE 'pending'::public.user_status END,
    v_team_leader
  );

  IF v_user_count = 0 THEN
    -- bootstrap CEO
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'ceo');
  ELSE
    INSERT INTO public.pending_approvals (user_id, requested_role, team_leader_id)
    VALUES (NEW.id, v_requested_role, v_team_leader);
  END IF;

  RETURN NEW;
END; $$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE TRIGGER profiles_updated_at BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

-- ============== RLS POLICIES ==============
-- profiles
CREATE POLICY "active users read profiles" ON public.profiles FOR SELECT
  TO authenticated USING (public.is_user_active(auth.uid()) OR id = auth.uid());
CREATE POLICY "users update own profile" ON public.profiles FOR UPDATE
  TO authenticated USING (id = auth.uid()) WITH CHECK (id = auth.uid());
CREATE POLICY "admins manage profiles" ON public.profiles FOR ALL
  TO authenticated USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));

-- user_roles
CREATE POLICY "users see own roles" ON public.user_roles FOR SELECT
  TO authenticated USING (user_id = auth.uid() OR public.is_admin(auth.uid()));
CREATE POLICY "admins manage roles" ON public.user_roles FOR ALL
  TO authenticated USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));

-- role_permissions
CREATE POLICY "authenticated read role perms" ON public.role_permissions FOR SELECT
  TO authenticated USING (true);
CREATE POLICY "admins manage role perms" ON public.role_permissions FOR ALL
  TO authenticated USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));

-- user_permission_overrides
CREATE POLICY "users see own overrides" ON public.user_permission_overrides FOR SELECT
  TO authenticated USING (user_id = auth.uid() OR public.is_admin(auth.uid()));
CREATE POLICY "admins manage overrides" ON public.user_permission_overrides FOR ALL
  TO authenticated USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));

-- pending_approvals
CREATE POLICY "users see own approval" ON public.pending_approvals FOR SELECT
  TO authenticated USING (user_id = auth.uid() OR public.is_admin(auth.uid()));
CREATE POLICY "admins manage approvals" ON public.pending_approvals FOR ALL
  TO authenticated USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));

-- audit_logs
CREATE POLICY "admins read audit" ON public.audit_logs FOR SELECT
  TO authenticated USING (public.is_admin(auth.uid()));
CREATE POLICY "authenticated insert audit" ON public.audit_logs FOR INSERT
  TO authenticated WITH CHECK (user_id = auth.uid());

-- ============== SEED DEFAULT ROLE PERMISSIONS ==============
-- All permissions list
WITH perms(k) AS (
  VALUES
    ('leads.view'),('leads.create'),('leads.edit'),('leads.delete'),
    ('leads.see_phone'),('leads.see_email'),('leads.see_notes'),
    ('leads.assign'),('leads.reassign'),('leads.delay'),('leads.import'),
    ('leads.see_all_sales_leads'),
    ('clients.view'),('clients.edit'),('clients.delete'),
    ('resale.view'),('resale.create'),('resale.edit'),('resale.delete'),
    ('resale.see_owner_info'),('resale.assign'),
    ('projects.view'),('projects.manage'),
    ('employees.view'),('employees.edit'),('employees.delete'),('employees.approve'),
    ('permissions.manage'),
    ('reports.view'),('reports.export'),
    ('dashboard.live'),('dashboard.tracking'),
    ('notifications.view'),
    ('planner.view'),('planner.edit'),
    ('profile.edit')
)
INSERT INTO public.role_permissions(role, permission_key, enabled)
SELECT r.role, p.k,
  CASE
    -- CEO / ADMIN: all true
    WHEN r.role IN ('ceo','admin') THEN true
    -- DIRECTOR
    WHEN r.role = 'director' AND p.k IN (
      'leads.view','leads.see_all_sales_leads','leads.reassign','leads.see_phone','leads.see_email','leads.see_notes',
      'clients.view','resale.view','resale.see_owner_info','projects.view',
      'employees.view','reports.view','reports.export','dashboard.live','dashboard.tracking',
      'notifications.view','planner.view','profile.edit'
    ) THEN true
    -- TEAM LEADER
    WHEN r.role = 'team_leader' AND p.k IN (
      'leads.view','leads.create','leads.edit','leads.see_phone','leads.see_email','leads.see_notes',
      'leads.assign','leads.delay','leads.import',
      'clients.view','resale.view','projects.view',
      'employees.view','reports.view',
      'notifications.view','planner.view','planner.edit','profile.edit'
    ) THEN true
    -- SALES
    WHEN r.role = 'sales' AND p.k IN (
      'leads.view','leads.edit','leads.see_phone','leads.delay',
      'resale.view','projects.view',
      'notifications.view','planner.view','planner.edit','profile.edit'
    ) THEN true
    ELSE false
  END
FROM (VALUES ('ceo'::public.app_role),('admin'),('director'),('team_leader'),('sales')) r(role)
CROSS JOIN perms p
ON CONFLICT (role, permission_key) DO NOTHING;
