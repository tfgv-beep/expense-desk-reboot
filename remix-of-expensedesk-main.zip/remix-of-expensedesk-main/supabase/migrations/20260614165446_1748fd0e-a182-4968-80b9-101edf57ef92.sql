
-- 1. Restrict audit_logs INSERT to a SECURITY DEFINER function
DROP POLICY IF EXISTS "authenticated insert audit" ON public.audit_logs;
REVOKE INSERT ON public.audit_logs FROM authenticated, anon;

CREATE OR REPLACE FUNCTION public.log_audit(_action text, _entity_type text, _entity_id text, _metadata jsonb DEFAULT '{}'::jsonb)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE v_id uuid;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'not authenticated';
  END IF;
  INSERT INTO public.audit_logs (user_id, action, entity_type, entity_id, metadata)
  VALUES (auth.uid(), _action, _entity_type, _entity_id, COALESCE(_metadata,'{}'::jsonb))
  RETURNING id INTO v_id;
  RETURN v_id;
END;$$;

REVOKE EXECUTE ON FUNCTION public.log_audit(text,text,text,jsonb) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.log_audit(text,text,text,jsonb) TO authenticated;

-- 2. Lock down SECURITY DEFINER helper functions: revoke from anon, keep authenticated only where needed
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.is_admin(uuid) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.has_permission(uuid, text) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.is_user_active(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.is_admin(uuid) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.has_permission(uuid, text) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.is_user_active(uuid) TO authenticated, service_role;

-- 3. Receipts bucket explicit DELETE/UPDATE restriction (owner-only) — leftover from prior app; lock it down
DROP POLICY IF EXISTS "receipts owner delete" ON storage.objects;
DROP POLICY IF EXISTS "receipts owner update" ON storage.objects;
CREATE POLICY "receipts owner delete" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'receipts' AND owner = auth.uid());
CREATE POLICY "receipts owner update" ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'receipts' AND owner = auth.uid())
  WITH CHECK (bucket_id = 'receipts' AND owner = auth.uid());
