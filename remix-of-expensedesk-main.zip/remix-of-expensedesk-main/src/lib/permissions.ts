export const PERMISSION_KEYS = [
  "leads.view","leads.create","leads.edit","leads.delete",
  "leads.see_phone","leads.see_email","leads.see_notes",
  "leads.assign","leads.reassign","leads.delay","leads.import",
  "leads.see_all_sales_leads",
  "clients.view","clients.edit","clients.delete",
  "resale.view","resale.create","resale.edit","resale.delete",
  "resale.see_owner_info","resale.assign",
  "projects.view","projects.manage",
  "employees.view","employees.edit","employees.delete","employees.approve",
  "permissions.manage",
  "reports.view","reports.export",
  "dashboard.live","dashboard.tracking",
  "notifications.view",
  "planner.view","planner.edit",
  "profile.edit",
] as const;

export type PermissionKey = (typeof PERMISSION_KEYS)[number];

export const PERMISSION_GROUPS: Record<string, PermissionKey[]> = {
  leads: PERMISSION_KEYS.filter(k => k.startsWith("leads.")) as PermissionKey[],
  clients: PERMISSION_KEYS.filter(k => k.startsWith("clients.")) as PermissionKey[],
  resale: PERMISSION_KEYS.filter(k => k.startsWith("resale.")) as PermissionKey[],
  projects: PERMISSION_KEYS.filter(k => k.startsWith("projects.")) as PermissionKey[],
  employees: PERMISSION_KEYS.filter(k => k.startsWith("employees.")) as PermissionKey[],
  reports: PERMISSION_KEYS.filter(k => k.startsWith("reports.")) as PermissionKey[],
  dashboard: PERMISSION_KEYS.filter(k => k.startsWith("dashboard.")) as PermissionKey[],
  other: ["permissions.manage","notifications.view","planner.view","planner.edit","profile.edit"],
};

export type AppRole = "ceo" | "admin" | "director" | "team_leader" | "sales";
export const ALL_ROLES: AppRole[] = ["ceo","admin","director","team_leader","sales"];
export const SIGNUP_ROLES: AppRole[] = ["admin","director","team_leader","sales"];
