import { createContext, useContext, useEffect, useState, ReactNode, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Session, User } from "@supabase/supabase-js";
import type { AppRole, PermissionKey } from "@/lib/permissions";

interface Profile {
  id: string;
  full_name: string;
  email: string;
  avatar_url: string | null;
  title: string | null;
  bio: string | null;
  phone: string | null;
  social_links: Record<string, string> | null;
  status: "pending" | "active" | "rejected" | "suspended";
  manager_id: string | null;
}

interface AuthCtx {
  user: User | null;
  session: Session | null;
  profile: Profile | null;
  roles: AppRole[];
  permissions: Set<string>;
  loading: boolean;
  signOut: () => Promise<void>;
  refresh: () => Promise<void>;
  hasPermission: (k: PermissionKey | string) => boolean;
  hasRole: (r: AppRole) => boolean;
  isAdmin: boolean;
}

const Ctx = createContext<AuthCtx | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [roles, setRoles] = useState<AppRole[]>([]);
  const [permissions, setPermissions] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);

  const loadUserData = useCallback(async (uid: string) => {
    const [{ data: prof }, { data: rs }, { data: overrides }] = await Promise.all([
      supabase.from("profiles").select("*").eq("id", uid).maybeSingle(),
      supabase.from("user_roles").select("role").eq("user_id", uid),
      supabase.from("user_permission_overrides").select("permission_key, enabled").eq("user_id", uid),
    ]);

    setProfile(prof as Profile | null);
    const roleList = (rs ?? []).map((r: any) => r.role as AppRole);
    setRoles(roleList);

    // Build permission set: union of role permissions + apply overrides
    let perms = new Set<string>();
    if (roleList.length > 0) {
      const { data: rp } = await supabase
        .from("role_permissions")
        .select("permission_key, enabled")
        .in("role", roleList);
      (rp ?? []).forEach((p: any) => { if (p.enabled) perms.add(p.permission_key); });
    }
    (overrides ?? []).forEach((o: any) => {
      if (o.enabled) perms.add(o.permission_key);
      else perms.delete(o.permission_key);
    });
    setPermissions(perms);
  }, []);

  const refresh = useCallback(async () => {
    if (user) await loadUserData(user.id);
  }, [user, loadUserData]);

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, sess) => {
      setSession(sess);
      setUser(sess?.user ?? null);
      if (sess?.user) {
        setTimeout(() => loadUserData(sess.user.id), 0);
      } else {
        setProfile(null); setRoles([]); setPermissions(new Set());
      }
    });

    supabase.auth.getSession().then(({ data: { session: s } }) => {
      setSession(s);
      setUser(s?.user ?? null);
      if (s?.user) loadUserData(s.user.id).finally(() => setLoading(false));
      else setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, [loadUserData]);

  const signOut = async () => { await supabase.auth.signOut(); };
  const hasPermission = (k: string) => permissions.has(k);
  const hasRole = (r: AppRole) => roles.includes(r);
  const isAdmin = roles.includes("ceo") || roles.includes("admin");

  return (
    <Ctx.Provider value={{ user, session, profile, roles, permissions, loading, signOut, refresh, hasPermission, hasRole, isAdmin }}>
      {children}
    </Ctx.Provider>
  );
}

export const useAuth = () => {
  const c = useContext(Ctx);
  if (!c) throw new Error("useAuth must be inside AuthProvider");
  return c;
};
