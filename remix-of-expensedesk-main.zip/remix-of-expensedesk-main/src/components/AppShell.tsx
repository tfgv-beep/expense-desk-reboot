import { ReactNode } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { motion } from "framer-motion";
import {
  LayoutDashboard, Users, Building2, Briefcase, ClipboardList,
  BarChart3, UserCheck, Shield, Settings as SettingsIcon, LogOut, UserCog, User as UserIcon,
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { LangThemeToggle } from "./LangThemeToggle";
import { Button } from "@/components/ui/button";

const navItems = [
  { to: "/dashboard", icon: LayoutDashboard, label: "nav.dashboard" },
  { to: "/leads", icon: Users, label: "nav.leads", perm: "leads.view" },
  { to: "/resale", icon: Building2, label: "nav.resale", perm: "resale.view" },
  { to: "/projects", icon: Briefcase, label: "nav.projects", perm: "projects.view" },
  { to: "/planner", icon: ClipboardList, label: "nav.planner", perm: "planner.view" },
  { to: "/reports", icon: BarChart3, label: "nav.reports", perm: "reports.view" },
];
const adminItems = [
  { to: "/admin/approvals", icon: UserCheck, label: "nav.approvals" },
  { to: "/admin/employees", icon: Users, label: "nav.employees" },
  { to: "/admin/permissions", icon: Shield, label: "nav.permissions" },
  { to: "/admin/overrides", icon: UserCog, label: "nav.overrides" },
];

export function AppShell({ children }: { children: ReactNode }) {
  const { t } = useTranslation();
  const { profile, roles, hasPermission, isAdmin, signOut } = useAuth();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex w-full">
      <aside className="w-64 bg-sidebar border-e border-sidebar-border flex flex-col">
        <div className="p-6 border-b border-sidebar-border">
          <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-gradient-primary flex items-center justify-center shadow-glow">
              <Building2 className="h-5 w-5 text-white" />
            </div>
            <div>
              <div className="font-bold text-base text-sidebar-foreground">{t("app.name")}</div>
              <div className="text-[11px] text-muted-foreground">{t("app.tagline")}</div>
            </div>
          </motion.div>
        </div>

        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            if (item.perm && !hasPermission(item.perm)) return null;
            const Icon = item.icon;
            return (
              <NavLink key={item.to} to={item.to}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                    isActive
                      ? "bg-gradient-primary text-white shadow-glow"
                      : "text-sidebar-foreground hover:bg-sidebar-accent"
                  }`}>
                <Icon className="h-4 w-4" /> {t(item.label)}
              </NavLink>
            );
          })}

          {isAdmin && (
            <>
              <div className="pt-4 pb-1 px-3 text-[11px] uppercase tracking-wider text-muted-foreground">Admin</div>
              {adminItems.map((item) => {
                const Icon = item.icon;
                return (
                  <NavLink key={item.to} to={item.to}
                    className={({ isActive }) =>
                      `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                        isActive
                          ? "bg-gradient-primary text-white shadow-glow"
                          : "text-sidebar-foreground hover:bg-sidebar-accent"
                      }`}>
                    <Icon className="h-4 w-4" /> {t(item.label)}
                  </NavLink>
                );
              })}
            </>
          )}
        </nav>

        <div className="p-3 border-t border-sidebar-border space-y-1">
          <NavLink to="/profile"
            className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-sidebar-foreground hover:bg-sidebar-accent">
            <UserIcon className="h-4 w-4" /> {t("nav.profile")}
          </NavLink>
          <button onClick={async () => { await signOut(); navigate("/login"); }}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-destructive hover:bg-destructive/10">
            <LogOut className="h-4 w-4" /> {t("common.logout")}
          </button>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-16 border-b bg-card/40 backdrop-blur-md flex items-center justify-between px-6">
          <div>
            <div className="font-semibold text-sm">{profile?.full_name}</div>
            <div className="text-xs text-muted-foreground">
              {roles.map(r => t(`roles.${r}`)).join(" · ")}
            </div>
          </div>
          <LangThemeToggle />
        </header>
        <main className="flex-1 overflow-y-auto p-6">{children}</main>
      </div>
    </div>
  );
}
