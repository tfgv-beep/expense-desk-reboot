import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Loader2 } from "lucide-react";
import type { PermissionKey } from "@/lib/permissions";

export function Protected({
  children,
  requirePermission,
  adminOnly,
}: {
  children: React.ReactNode;
  requirePermission?: PermissionKey;
  adminOnly?: boolean;
}) {
  const { user, profile, loading, hasPermission, isAdmin } = useAuth();
  const location = useLocation();

  if (loading) {
    return <div className="min-h-screen grid place-items-center"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>;
  }
  if (!user) return <Navigate to="/login" state={{ from: location }} replace />;
  if (profile?.status === "pending") return <Navigate to="/pending" replace />;
  if (profile?.status === "rejected" || profile?.status === "suspended") {
    return <Navigate to="/pending" replace />;
  }
  if (adminOnly && !isAdmin) return <Navigate to="/dashboard" replace />;
  if (requirePermission && !hasPermission(requirePermission)) {
    return <Navigate to="/dashboard" replace />;
  }
  return <>{children}</>;
}
