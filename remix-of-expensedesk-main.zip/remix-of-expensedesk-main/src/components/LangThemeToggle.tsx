import { useTranslation } from "react-i18next";
import { Moon, Sun, Languages } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useTheme } from "@/contexts/ThemeContext";

export function LangThemeToggle() {
  const { i18n } = useTranslation();
  const { theme, toggle } = useTheme();
  const switchLang = () => i18n.changeLanguage(i18n.language === "ar" ? "en" : "ar");

  return (
    <div className="flex items-center gap-2">
      <Button variant="ghost" size="icon" onClick={switchLang} title="Language">
        <Languages className="h-4 w-4" />
        <span className="sr-only">Switch language</span>
      </Button>
      <Button variant="ghost" size="icon" onClick={toggle} title="Theme">
        {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
      </Button>
    </div>
  );
}
