import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { ThemeProvider } from "@/contexts/ThemeContext";
import { AuthProvider } from "@/contexts/AuthContext";
import { Protected } from "@/components/Protected";
import { AppShell } from "@/components/AppShell";

import Login from "./pages/Login";
import Signup from "./pages/Signup";
import ForgotPassword from "./pages/ForgotPassword";
import ResetPassword from "./pages/ResetPassword";
import VerifyEmail from "./pages/VerifyEmail";
import PendingApproval from "./pages/PendingApproval";
import Dashboard from "./pages/Dashboard";
import Profile from "./pages/Profile";
import Approvals from "./pages/admin/Approvals";
import Employees from "./pages/admin/Employees";
import EmployeeDetail from "./pages/admin/EmployeeDetail";
import PermissionsMatrix from "./pages/admin/PermissionsMatrix";
import UserOverrides from "./pages/admin/UserOverrides";
import Placeholder from "./pages/Placeholder";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const ProtectedShell = ({ children, ...props }: any) => (
  <Protected {...props}><AppShell>{children}</AppShell></Protected>
);

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <AuthProvider>
            <Routes>
              <Route path="/" element={<Navigate to="/dashboard" replace />} />
              <Route path="/login" element={<Login />} />
              <Route path="/signup" element={<Signup />} />
              <Route path="/forgot-password" element={<ForgotPassword />} />
              <Route path="/reset-password" element={<ResetPassword />} />
              <Route path="/verify-email" element={<VerifyEmail />} />
              <Route path="/pending" element={<PendingApproval />} />

              <Route path="/dashboard" element={<ProtectedShell><Dashboard /></ProtectedShell>} />
              <Route path="/profile" element={<ProtectedShell><Profile /></ProtectedShell>} />
              <Route path="/leads" element={<ProtectedShell requirePermission="leads.view"><Placeholder title="Leads" /></ProtectedShell>} />
              <Route path="/resale" element={<ProtectedShell requirePermission="resale.view"><Placeholder title="Resale Market" /></ProtectedShell>} />
              <Route path="/projects" element={<ProtectedShell requirePermission="projects.view"><Placeholder title="Projects" /></ProtectedShell>} />
              <Route path="/planner" element={<ProtectedShell requirePermission="planner.view"><Placeholder title="Planner" /></ProtectedShell>} />
              <Route path="/reports" element={<ProtectedShell requirePermission="reports.view"><Placeholder title="Reports" /></ProtectedShell>} />

              <Route path="/admin/approvals" element={<ProtectedShell adminOnly><Approvals /></ProtectedShell>} />
              <Route path="/admin/employees" element={<ProtectedShell adminOnly><Employees /></ProtectedShell>} />
              <Route path="/admin/employees/:id" element={<ProtectedShell adminOnly><EmployeeDetail /></ProtectedShell>} />
              <Route path="/admin/permissions" element={<ProtectedShell adminOnly><PermissionsMatrix /></ProtectedShell>} />
              <Route path="/admin/overrides" element={<ProtectedShell adminOnly><UserOverrides /></ProtectedShell>} />

              <Route path="*" element={<NotFound />} />
            </Routes>
          </AuthProvider>
        </BrowserRouter>
      </TooltipProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
