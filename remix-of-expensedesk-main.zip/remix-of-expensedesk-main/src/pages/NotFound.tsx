import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="min-h-screen grid place-items-center">
      <div className="text-center">
        <div className="text-7xl font-bold bg-gradient-primary bg-clip-text text-transparent">404</div>
        <p className="text-muted-foreground mt-2 mb-6">Page not found</p>
        <Button asChild><Link to="/dashboard">Home</Link></Button>
      </div>
    </div>
  );
}
