import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { ArrowRight, ArrowLeft } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export default function EmployeeDetail() {
  const { id } = useParams();
  const { t, i18n } = useTranslation();
  const [profile, setProfile] = useState<any>(null);
  const [roles, setRoles] = useState<string[]>([]);

  const load = async () => {
    if (!id) return;
    const [{ data: p }, { data: rs }] = await Promise.all([
      supabase.from("profiles").select("*").eq("id", id).maybeSingle(),
      supabase.from("user_roles").select("role").eq("user_id", id),
    ]);
    setProfile(p);
    setRoles((rs ?? []).map((r: any) => r.role));
  };
  useEffect(() => { load(); }, [id]);

  const save = async (patch: any) => {
    const { error } = await supabase.from("profiles").update(patch).eq("id", id!);
    if (error) toast.error(error.message); else { toast.success("✓"); load(); }
  };

  const Arrow = i18n.language === "ar" ? ArrowRight : ArrowLeft;

  if (!profile) return <p>{t("common.loading")}</p>;
  return (
    <div className="max-w-3xl mx-auto">
      <Button asChild variant="ghost" className="mb-4"><Link to="/admin/employees"><Arrow className="h-4 w-4 me-1" />{t("common.back")}</Link></Button>
      <Card className="glass p-6">
        <div className="flex items-center gap-4 mb-6">
          <div className="w-20 h-20 rounded-2xl bg-gradient-primary grid place-items-center text-white text-2xl font-bold">
            {profile.full_name.slice(0, 1)}
          </div>
          <div className="flex-1">
            <h1 className="text-2xl font-bold">{profile.full_name}</h1>
            <div className="text-sm text-muted-foreground">{profile.email}</div>
            <div className="flex gap-2 mt-2">
              {roles.map(r => <Badge key={r}>{t(`roles.${r}`)}</Badge>)}
              <Badge variant={profile.status === "active" ? "default" : "outline"}>{t(`status.${profile.status}`)}</Badge>
            </div>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div><Label>{t("auth.fullName")}</Label>
            <Input defaultValue={profile.full_name} onBlur={(e) => save({ full_name: e.target.value })} />
          </div>
          <div><Label>Title</Label>
            <Input defaultValue={profile.title ?? ""} onBlur={(e) => save({ title: e.target.value })} />
          </div>
          <div><Label>Phone</Label>
            <Input defaultValue={profile.phone ?? ""} onBlur={(e) => save({ phone: e.target.value })} />
          </div>
          <div><Label>Status</Label>
            <select defaultValue={profile.status} className="w-full h-10 rounded-md border bg-background px-3"
              onChange={(e) => save({ status: e.target.value })}>
              {["active","pending","suspended","rejected"].map(s => <option key={s} value={s}>{t(`status.${s}`)}</option>)}
            </select>
          </div>
        </div>
        <p className="text-sm text-muted-foreground mt-6">📊 {t("admin.employees.performance")}: متربط بالـ leads — هيظهر في Phase 2 ✨</p>
      </Card>
    </div>
  );
}
