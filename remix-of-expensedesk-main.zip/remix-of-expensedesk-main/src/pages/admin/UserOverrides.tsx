import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { PERMISSION_GROUPS, PERMISSION_KEYS } from "@/lib/permissions";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";

export default function UserOverrides() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [users, setUsers] = useState<{ id: string; full_name: string; email: string }[]>([]);
  const [selected, setSelected] = useState<string>("");
  const [rolePerms, setRolePerms] = useState<Set<string>>(new Set());
  const [overrides, setOverrides] = useState<Record<string, boolean>>({});

  useEffect(() => {
    supabase.from("profiles").select("id, full_name, email").eq("status", "active")
      .then(({ data }) => setUsers((data ?? []) as any));
  }, []);

  useEffect(() => {
    if (!selected) return;
    (async () => {
      const { data: roles } = await supabase.from("user_roles").select("role").eq("user_id", selected);
      const roleList = (roles ?? []).map((r: any) => r.role);
      const set = new Set<string>();
      if (roleList.length) {
        const { data: rp } = await supabase.from("role_permissions")
          .select("permission_key, enabled").in("role", roleList);
        (rp ?? []).forEach((p: any) => { if (p.enabled) set.add(p.permission_key); });
      }
      setRolePerms(set);
      const { data: ov } = await supabase.from("user_permission_overrides")
        .select("permission_key, enabled").eq("user_id", selected);
      const obj: Record<string, boolean> = {};
      (ov ?? []).forEach((o: any) => obj[o.permission_key] = o.enabled);
      setOverrides(obj);
    })();
  }, [selected]);

  const setOverride = async (key: string, mode: "inherit" | "on" | "off") => {
    if (mode === "inherit") {
      const { error } = await supabase.from("user_permission_overrides")
        .delete().eq("user_id", selected).eq("permission_key", key);
      if (error) { toast.error(error.message); return; }
      setOverrides(prev => { const n = { ...prev }; delete n[key]; return n; });
    } else {
      const enabled = mode === "on";
      const { error } = await supabase.from("user_permission_overrides")
        .upsert({ user_id: selected, permission_key: key, enabled, set_by: user!.id, updated_at: new Date().toISOString() },
                { onConflict: "user_id,permission_key" });
      if (error) { toast.error(error.message); return; }
      setOverrides(prev => ({ ...prev, [key]: enabled }));
    }
    toast.success("✓");
  };

  const effective = (k: string) => k in overrides ? overrides[k] : rolePerms.has(k);

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold">{t("admin.overrides.title")}</h1>
        <p className="text-sm text-muted-foreground">{t("admin.overrides.subtitle")}</p>
      </div>

      <Card className="glass p-4 mb-6">
        <label className="text-sm font-medium mb-2 block">{t("admin.overrides.selectUser")}</label>
        <Select value={selected} onValueChange={setSelected}>
          <SelectTrigger><SelectValue placeholder="—" /></SelectTrigger>
          <SelectContent>
            {users.map(u => <SelectItem key={u.id} value={u.id}>{u.full_name} ({u.email})</SelectItem>)}
          </SelectContent>
        </Select>
      </Card>

      {selected && (
        <div className="space-y-4">
          {Object.entries(PERMISSION_GROUPS).map(([group, keys]) => (
            <Card key={group} className="glass overflow-hidden">
              <div className="px-5 py-3 border-b bg-card/50 font-semibold uppercase text-xs tracking-wider">{group}</div>
              <div className="divide-y divide-border/50">
                {keys.map(k => {
                  const has = k in overrides;
                  const mode = !has ? "inherit" : overrides[k] ? "on" : "off";
                  return (
                    <div key={k} className="flex items-center justify-between p-3 hover:bg-card/40">
                      <div>
                        <div className="text-sm">{t(`permissions.${k}`)}</div>
                        <div className="text-xs text-muted-foreground">
                          {effective(k) ? "✓ " : "✗ "}{rolePerms.has(k) ? "role: on" : "role: off"}
                          {has && <span className="ms-2"><Badge variant="outline" className="text-[10px]">override</Badge></span>}
                        </div>
                      </div>
                      <select value={mode}
                        onChange={(e) => setOverride(k, e.target.value as any)}
                        className="h-9 rounded-md border bg-background px-3 text-sm">
                        <option value="inherit">{t("admin.overrides.inherit")}</option>
                        <option value="on">{t("admin.overrides.enabled")}</option>
                        <option value="off">{t("admin.overrides.disabled")}</option>
                      </select>
                    </div>
                  );
                })}
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
