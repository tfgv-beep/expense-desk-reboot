import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Check, X, Pencil, UserCheck } from "lucide-react";
import { ALL_ROLES, type AppRole } from "@/lib/permissions";
import { useAuth } from "@/contexts/AuthContext";

interface PendingItem {
  id: string;
  user_id: string;
  requested_role: AppRole;
  team_leader_id: string | null;
  status: string;
  created_at: string;
  profile: { full_name: string; email: string; phone: string | null; status: string };
  team_leader?: { full_name: string } | null;
}

export default function Approvals() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [items, setItems] = useState<PendingItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<PendingItem | null>(null);
  const [editRole, setEditRole] = useState<AppRole>("sales");
  const [editName, setEditName] = useState("");

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("pending_approvals")
      .select(`id, user_id, requested_role, team_leader_id, status, created_at,
               profile:profiles!pending_approvals_user_id_fkey(full_name, email, phone, status),
               team_leader:profiles!pending_approvals_team_leader_id_fkey(full_name)`)
      .eq("status", "pending")
      .order("created_at", { ascending: false });
    setLoading(false);
    if (error) { toast.error(error.message); return; }
    setItems((data as any) ?? []);
  };
  useEffect(() => { load(); }, []);

  const approve = async (it: PendingItem, role: AppRole) => {
    const { error: roleErr } = await supabase.from("user_roles").insert({ user_id: it.user_id, role });
    if (roleErr && !roleErr.message.includes("duplicate")) { toast.error(roleErr.message); return; }
    const { error: profErr } = await supabase.from("profiles").update({ status: "active" }).eq("id", it.user_id);
    if (profErr) { toast.error(profErr.message); return; }
    await supabase.from("pending_approvals").update({
      status: "approved", reviewed_by: user!.id, reviewed_at: new Date().toISOString(),
    }).eq("id", it.id);
    await supabase.from("audit_logs").insert({
      user_id: user!.id, action: "approve_user", entity_type: "user", entity_id: it.user_id, metadata: { role },
    });
    toast.success(t("admin.approvals.approved"));
    load();
  };

  const reject = async (it: PendingItem) => {
    await supabase.from("profiles").update({ status: "rejected" }).eq("id", it.user_id);
    await supabase.from("pending_approvals").update({
      status: "rejected", reviewed_by: user!.id, reviewed_at: new Date().toISOString(),
    }).eq("id", it.id);
    await supabase.from("audit_logs").insert({
      user_id: user!.id, action: "reject_user", entity_type: "user", entity_id: it.user_id,
    });
    toast.success(t("admin.approvals.rejected"));
    load();
  };

  const openEdit = (it: PendingItem) => {
    setEditing(it);
    setEditRole(it.requested_role);
    setEditName(it.profile.full_name);
  };

  const saveEdit = async () => {
    if (!editing) return;
    await supabase.from("profiles").update({ full_name: editName }).eq("id", editing.user_id);
    await supabase.from("pending_approvals").update({ requested_role: editRole }).eq("id", editing.id);
    setEditing(null);
    load();
  };

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold">{t("admin.approvals.title")}</h1>
        <p className="text-sm text-muted-foreground">{t("admin.approvals.subtitle")}</p>
      </div>

      {loading ? <p>{t("common.loading")}</p> :
       items.length === 0 ? (
        <Card className="glass p-12 text-center">
          <UserCheck className="h-12 w-12 mx-auto mb-3 text-muted-foreground" />
          <p className="text-muted-foreground">{t("admin.approvals.noRequests")}</p>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          <AnimatePresence>
            {items.map((it) => (
              <motion.div key={it.id}
                initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9 }}
                layout>
                <Card className="glass p-5">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 rounded-xl bg-gradient-primary grid place-items-center text-white font-bold">
                      {it.profile.full_name.slice(0, 1)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold truncate">{it.profile.full_name}</div>
                      <div className="text-xs text-muted-foreground truncate">{it.profile.email}</div>
                    </div>
                    <Badge variant="secondary">{t(`roles.${it.requested_role}`)}</Badge>
                  </div>
                  <div className="text-xs space-y-1 mb-4">
                    {it.profile.phone && <div className="text-muted-foreground">📱 {it.profile.phone}</div>}
                    {it.team_leader && <div className="text-muted-foreground">👤 {t("admin.approvals.teamLeader")}: {it.team_leader.full_name}</div>}
                    <div className="text-muted-foreground">📅 {new Date(it.created_at).toLocaleDateString()}</div>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" className="flex-1 bg-gradient-primary" onClick={() => approve(it, it.requested_role)}>
                      <Check className="h-4 w-4 me-1" />{t("common.approve")}
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => openEdit(it)}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="destructive" onClick={() => reject(it)}>
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}

      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>{t("common.edit")}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div><Label>{t("auth.fullName")}</Label><Input value={editName} onChange={(e) => setEditName(e.target.value)} /></div>
            <div>
              <Label>{t("common.role")}</Label>
              <Select value={editRole} onValueChange={(v) => setEditRole(v as AppRole)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {ALL_ROLES.map(r => <SelectItem key={r} value={r}>{t(`roles.${r}`)}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditing(null)}>{t("common.cancel")}</Button>
            <Button onClick={saveEdit} className="bg-gradient-primary">{t("common.save")}</Button>
            <Button onClick={() => editing && approve(editing, editRole)} className="bg-success text-success-foreground">
              {t("common.save")} + {t("common.approve")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
