import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { supabase } from "@/integrations/supabase/client";
import { ALL_ROLES, PERMISSION_GROUPS, PERMISSION_KEYS, type AppRole } from "@/lib/permissions";
import { toast } from "sonner";

type Matrix = Record<string, Record<AppRole, boolean>>;

export default function PermissionsMatrix() {
  const { t } = useTranslation();
  const [matrix, setMatrix] = useState<Matrix>({});
  const [loading, setLoading] = useState(true);

  const load = async () => {
    const { data } = await supabase.from("role_permissions").select("role, permission_key, enabled");
    const m: Matrix = {};
    PERMISSION_KEYS.forEach(k => {
      m[k] = { ceo: false, admin: false, director: false, team_leader: false, sales: false };
    });
    (data ?? []).forEach((r: any) => {
      if (!m[r.permission_key]) m[r.permission_key] = { ceo: false, admin: false, director: false, team_leader: false, sales: false };
      m[r.permission_key][r.role as AppRole] = r.enabled;
    });
    setMatrix(m);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const toggle = async (key: string, role: AppRole, enabled: boolean) => {
    setMatrix(prev => ({ ...prev, [key]: { ...prev[key], [role]: enabled } }));
    const { error } = await supabase.from("role_permissions")
      .upsert({ role, permission_key: key, enabled, updated_at: new Date().toISOString() }, { onConflict: "role,permission_key" });
    if (error) { toast.error(error.message); load(); }
    else toast.success(t("admin.permissions.savedToast"));
  };

  if (loading) return <p>{t("common.loading")}</p>;

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold">{t("admin.permissions.title")}</h1>
        <p className="text-sm text-muted-foreground">{t("admin.permissions.subtitle")}</p>
      </div>
      <div className="space-y-4">
        {Object.entries(PERMISSION_GROUPS).map(([group, keys]) => (
          <Card key={group} className="glass overflow-hidden">
            <div className="px-5 py-3 border-b bg-card/50 font-semibold uppercase text-xs tracking-wider">{group}</div>
            <table className="w-full">
              <thead className="text-xs text-muted-foreground">
                <tr className="border-b">
                  <th className="text-start p-3 font-medium">{t("admin.permissions.permission")}</th>
                  {ALL_ROLES.map(r => <th key={r} className="p-3 text-center font-medium">{t(`roles.${r}`)}</th>)}
                </tr>
              </thead>
              <tbody>
                {keys.map(k => (
                  <tr key={k} className="border-b border-border/50 hover:bg-card/40">
                    <td className="p-3 text-sm">{t(`permissions.${k}`)}</td>
                    {ALL_ROLES.map(r => (
                      <td key={r} className="p-3 text-center">
                        <div className="flex justify-center">
                          <Switch
                            checked={matrix[k]?.[r] ?? false}
                            onCheckedChange={(v) => toggle(k, r, v)}
                            disabled={r === "ceo"}
                          />
                        </div>
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>
        ))}
      </div>
    </div>
  );
}
