import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";

interface Row { id: string; full_name: string; email: string; status: string; title: string | null; roles: string[] }

export default function Employees() {
  const { t } = useTranslation();
  const [rows, setRows] = useState<Row[]>([]);
  const [q, setQ] = useState("");

  useEffect(() => {
    (async () => {
      const { data: profs } = await supabase.from("profiles").select("id, full_name, email, status, title");
      const { data: roles } = await supabase.from("user_roles").select("user_id, role");
      const byUser: Record<string, string[]> = {};
      (roles ?? []).forEach((r: any) => {
        byUser[r.user_id] = byUser[r.user_id] || [];
        byUser[r.user_id].push(r.role);
      });
      setRows((profs ?? []).map((p: any) => ({ ...p, roles: byUser[p.id] ?? [] })));
    })();
  }, []);

  const filtered = rows.filter(r =>
    r.full_name.toLowerCase().includes(q.toLowerCase()) ||
    r.email.toLowerCase().includes(q.toLowerCase())
  );

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">{t("admin.employees.title")}</h1>
          <p className="text-sm text-muted-foreground">{rows.length} total</p>
        </div>
        <Input placeholder={t("common.search")} value={q} onChange={(e) => setQ(e.target.value)} className="max-w-xs" />
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((r, i) => (
          <motion.div key={r.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}
            whileHover={{ y: -3 }}>
            <Link to={`/admin/employees/${r.id}`}>
              <Card className="glass p-5 cursor-pointer">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-primary grid place-items-center text-white font-bold">
                    {r.full_name.slice(0, 1)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold truncate">{r.full_name}</div>
                    <div className="text-xs text-muted-foreground truncate">{r.email}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2 mt-3 flex-wrap">
                  {r.roles.map(role => <Badge key={role} variant="secondary">{t(`roles.${role}`)}</Badge>)}
                  <Badge variant={r.status === "active" ? "default" : "outline"}>{t(`status.${r.status}`)}</Badge>
                </div>
              </Card>
            </Link>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
