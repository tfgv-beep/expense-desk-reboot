import { useTranslation } from "react-i18next";
import { motion } from "framer-motion";
import { Users, Building2, ClipboardList, BarChart3 } from "lucide-react";
import { Card } from "@/components/ui/card";
import { useAuth } from "@/contexts/AuthContext";

const cards = [
  { icon: Users, key: "nav.leads", color: "from-indigo-500 to-violet-500" },
  { icon: Building2, key: "nav.resale", color: "from-cyan-500 to-blue-500" },
  { icon: ClipboardList, key: "nav.planner", color: "from-emerald-500 to-teal-500" },
  { icon: BarChart3, key: "nav.reports", color: "from-pink-500 to-rose-500" },
];

export default function Dashboard() {
  const { t } = useTranslation();
  const { profile } = useAuth();

  return (
    <div>
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-3xl font-bold mb-1">أهلاً، {profile?.full_name} 👋</h1>
        <p className="text-muted-foreground mb-8">{t("app.tagline")}</p>
      </motion.div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map((c, i) => {
          const Icon = c.icon;
          return (
            <motion.div key={c.key}
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }}
              whileHover={{ y: -4, scale: 1.02 }}>
              <Card className="p-6 glass cursor-pointer overflow-hidden relative h-36">
                <div className={`absolute -top-8 -end-8 w-32 h-32 rounded-full bg-gradient-to-br ${c.color} opacity-20 blur-2xl`} />
                <Icon className="h-8 w-8 mb-3 text-primary" />
                <div className="font-semibold text-lg">{t(c.key)}</div>
                <div className="text-xs text-muted-foreground mt-1">— قريباً —</div>
              </Card>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
