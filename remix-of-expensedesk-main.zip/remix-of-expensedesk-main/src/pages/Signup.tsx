import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { motion } from "framer-motion";
import { Building2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { LangThemeToggle } from "@/components/LangThemeToggle";
import { SIGNUP_ROLES, type AppRole } from "@/lib/permissions";

export default function Signup() {
  const { t } = useTranslation();
  const nav = useNavigate();
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [role, setRole] = useState<AppRole>("sales");
  const [teamLeaderId, setTeamLeaderId] = useState<string>("");
  const [teamLeaders, setTeamLeaders] = useState<{ id: string; full_name: string }[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (role !== "sales") return;
    // Public list of active team leaders -> need a separate fetch via RPC ideally; for now we hit profiles (visible only after auth).
    // We'll allow choosing later; show empty option until logged in.
    supabase
      .from("profiles")
      .select("id, full_name")
      .eq("status", "active")
      .then(({ data }) => setTeamLeaders((data as any) ?? []));
  }, [role]);

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password.length < 8) { toast.error(t("auth.passwordTooShort")); return; }
    if (password !== confirm) { toast.error(t("auth.passwordMismatch")); return; }
    setLoading(true);
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: `${window.location.origin}/dashboard`,
        data: {
          full_name: fullName,
          requested_role: role,
          ...(role === "sales" && teamLeaderId ? { team_leader_id: teamLeaderId } : {}),
        },
      },
    });
    setLoading(false);
    if (error) { toast.error(error.message); return; }
    nav("/verify-email", { replace: true });
  };

  const handleGoogle = async () => {
    const res = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
    if (res.error) toast.error(res.error.message ?? "Google sign-in failed");
  };

  return (
    <div className="min-h-screen flex">
      <div className="hidden lg:flex flex-1 bg-gradient-primary relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_30%,rgba(255,255,255,0.15),transparent_50%)]" />
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
          className="relative z-10 m-auto text-white max-w-md p-12">
          <Building2 className="h-12 w-12 mb-6" />
          <h1 className="text-4xl font-bold mb-3">{t("auth.joinTeam")}</h1>
          <p className="text-lg text-white/80">{t("app.tagline")}</p>
        </motion.div>
      </div>

      <div className="flex-1 flex items-center justify-center p-6 relative">
        <div className="absolute top-4 end-4"><LangThemeToggle /></div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
          <Card className="glass p-8 shadow-card">
            <h2 className="text-2xl font-bold mb-1">{t("auth.createAccount")}</h2>
            <p className="text-sm text-muted-foreground mb-6">{t("auth.signup")}</p>

            <form onSubmit={handleSignup} className="space-y-3">
              <div>
                <Label>{t("auth.fullName")}</Label>
                <Input required value={fullName} onChange={(e) => setFullName(e.target.value)} />
              </div>
              <div>
                <Label>{t("auth.email")}</Label>
                <Input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>{t("auth.password")}</Label>
                  <Input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} />
                </div>
                <div>
                  <Label>{t("auth.confirmPassword")}</Label>
                  <Input type="password" required value={confirm} onChange={(e) => setConfirm(e.target.value)} />
                </div>
              </div>
              <div>
                <Label>{t("auth.selectRole")}</Label>
                <Select value={role} onValueChange={(v) => setRole(v as AppRole)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {SIGNUP_ROLES.map((r) => (
                      <SelectItem key={r} value={r}>{t(`roles.${r}`)}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {role === "sales" && (
                <div>
                  <Label>{t("auth.teamLeader")}</Label>
                  <Select value={teamLeaderId} onValueChange={setTeamLeaderId}>
                    <SelectTrigger><SelectValue placeholder={t("auth.selectTeamLeader")} /></SelectTrigger>
                    <SelectContent>
                      {teamLeaders.length === 0 && <SelectItem value="none" disabled>—</SelectItem>}
                      {teamLeaders.map((tl) => (
                        <SelectItem key={tl.id} value={tl.id}>{tl.full_name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
              <Button type="submit" className="w-full bg-gradient-primary shadow-glow mt-2" disabled={loading}>
                {loading ? t("common.loading") : t("auth.signup")}
              </Button>
            </form>

            <div className="my-4 flex items-center gap-3">
              <div className="flex-1 h-px bg-border" />
              <span className="text-xs text-muted-foreground">{t("auth.or")}</span>
              <div className="flex-1 h-px bg-border" />
            </div>

            <Button variant="outline" className="w-full" onClick={handleGoogle}>
              {t("auth.continueWithGoogle")}
            </Button>

            <p className="text-center text-sm text-muted-foreground mt-6">
              {t("auth.haveAccount")} <Link to="/login" className="text-primary font-medium hover:underline">{t("auth.login")}</Link>
            </p>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
