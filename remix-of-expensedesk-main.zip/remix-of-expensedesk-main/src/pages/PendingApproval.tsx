import { useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { motion } from "framer-motion";
import { Clock } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { LangThemeToggle } from "@/components/LangThemeToggle";
import { useEffect } from "react";

export default function PendingApproval() {
  const { t } = useTranslation();
  const nav = useNavigate();
  const { profile, signOut, loading } = useAuth();

  useEffect(() => {
    if (!loading && profile?.status === "active") nav("/dashboard", { replace: true });
  }, [profile, loading, nav]);

  return (
    <div className="min-h-screen grid place-items-center p-6 relative">
      <div className="absolute top-4 end-4"><LangThemeToggle /></div>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
        <Card className="glass p-10 text-center shadow-card">
          <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-primary grid place-items-center shadow-glow">
            <Clock className="h-8 w-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold mb-2">{t("auth.pendingApproval")}</h2>
          <p className="text-sm text-muted-foreground mb-6">{t("auth.pendingDescription")}</p>
          <Button variant="outline" onClick={async () => { await signOut(); nav("/login"); }}>
            {t("common.logout")}
          </Button>
        </Card>
      </motion.div>
    </div>
  );
}
