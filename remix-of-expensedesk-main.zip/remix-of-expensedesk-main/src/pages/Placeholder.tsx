import { useTranslation } from "react-i18next";
import { Card } from "@/components/ui/card";

export default function Placeholder({ title }: { title: string }) {
  return (
    <div className="grid place-items-center min-h-[60vh]">
      <Card className="glass p-10 text-center max-w-md">
        <h2 className="text-2xl font-bold mb-2">{title}</h2>
        <p className="text-muted-foreground">قريباً — هتتبني في Phase التالية ✨</p>
      </Card>
    </div>
  );
}
