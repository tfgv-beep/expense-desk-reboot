import { useState } from "react";
import { useTranslation } from "react-i18next";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";

export default function Profile() {
  const { t } = useTranslation();
  const { profile, refresh } = useAuth();
  const [full_name, setFullName] = useState(profile?.full_name ?? "");
  const [title, setTitle] = useState(profile?.title ?? "");
  const [bio, setBio] = useState(profile?.bio ?? "");
  const [phone, setPhone] = useState(profile?.phone ?? "");
  const social = (profile?.social_links ?? {}) as Record<string, string>;
  const [facebook, setFacebook] = useState(social.facebook ?? "");
  const [instagram, setInstagram] = useState(social.instagram ?? "");
  const [loading, setLoading] = useState(false);

  const save = async () => {
    if (!profile) return;
    setLoading(true);
    const { error } = await supabase
      .from("profiles")
      .update({ full_name, title, bio, phone, social_links: { facebook, instagram } })
      .eq("id", profile.id);
    setLoading(false);
    if (error) { toast.error(error.message); return; }
    await refresh();
    toast.success("✓");
  };

  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">{t("nav.profile")}</h1>
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        <Card className="p-6 glass">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-20 h-20 rounded-2xl bg-gradient-primary grid place-items-center text-white text-2xl font-bold shadow-glow">
              {(profile?.full_name ?? "?").slice(0, 1)}
            </div>
            <div>
              <div className="font-bold text-lg">{profile?.full_name}</div>
              <div className="text-sm text-muted-foreground">{profile?.email}</div>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div><Label>{t("auth.fullName")}</Label><Input value={full_name} onChange={(e) => setFullName(e.target.value)} /></div>
            <div><Label>Title</Label><Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Senior Sales" /></div>
            <div><Label>Phone</Label><Input value={phone} onChange={(e) => setPhone(e.target.value)} /></div>
            <div><Label>Facebook</Label><Input value={facebook} onChange={(e) => setFacebook(e.target.value)} /></div>
            <div><Label>Instagram</Label><Input value={instagram} onChange={(e) => setInstagram(e.target.value)} /></div>
            <div className="md:col-span-2"><Label>Bio</Label><Textarea value={bio} onChange={(e) => setBio(e.target.value)} /></div>
          </div>
          <div className="mt-6 flex justify-end">
            <Button onClick={save} disabled={loading} className="bg-gradient-primary">{loading ? "..." : t("common.save")}</Button>
          </div>
        </Card>
      </motion.div>
    </div>
  );
}
